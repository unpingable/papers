# PEP 653: Precise Semantics for Pattern Matching

**Source URL:** https://peps.python.org/pep-0653/
**Fetched:** 2026-06-06 via WebFetch (summarized with verbatim critical quotes)
**Altitude:** post-acceptance regret / re-specification / explicit critique of PEP 634
**Status note:** Follow-up PEP that exists *because* PEP 634 was viewed as under-specified. Not necessarily Accepted/Final; relevant regardless of formal status for this audit because its mere existence is evidence of the gap.

## Abstract (summary)

PEP 653 proposes semantics for pattern matching that improves upon PEP 634 by being "more precise, easier to reason about, and should be faster." The proposal adds two special attributes to the object model: `__match_container__` and `__match_class__`, alongside the existing `__match_args__`.

## Motivation (verbatim critique of PEP 634)

**Precise Semantics (direct PEP 634 criticism):**

> *"PEP 634 explicitly includes a section on undefined behavior. Large amounts of undefined behavior may be acceptable in a language like C, but in Python it should be kept to a minimum. Pattern matching in Python can be defined more precisely without losing expressiveness or performance."*

**Improved Control:**

PEP 634 "privileges some builtin classes with a special form of matching, the 'self' match" and "delegates the decision over whether a class is a sequence or mapping to `collections.abc`."

**Robustness:**

> *"with this PEP, access to attributes during pattern matching becomes well defined and deterministic"* — addressing concerns about "object-relational mappers" and "unintended consequences should attribute access have side-effects."

## Key Differences from PEP 634

- Uses `cls.__match_container__` instead of `issubclass()` checks against abstract base classes
- Requires `__match_args__` to be a **tuple** rather than any sequence
- Allows `__match_class__ = 0` to opt out of deconstruction
- Provides explicit, deterministic semantics for all matching scenarios

## Specification Highlights

The proposal defines precise translation rules for all pattern types (capture, wildcard, literal, value, sequence, mapping, and class patterns) into pseudo-code with temporary variables and explicit failure points.


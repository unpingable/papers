# PEP 635: Structural Pattern Matching — Motivation and Rationale

**Source URL:** https://peps.python.org/pep-0635/
**Fetched:** 2026-06-06 via WebFetch (partially verbatim, with extensive direct quotation)
**Altitude:** argument / rationale (this is the closest thing PEPs have to a frozen discussion-archaeology layer)

## Abstract

PEP 635 provides the motivation and rationale for PEP 634 ("Structural Pattern Matching: Specification"). Readers new to the topic should start with PEP 636.

## Motivation

### Overview

"(Structural) pattern matching syntax is found in many languages, from Haskell, Erlang and Scala to Elixir and Ruby." Python currently supports limited pattern matching through sequence unpacking assignments.

### Common Python Idioms Enhanced by Pattern Matching

**Type and Shape Checking:**
```python
# Before
if isinstance(x, tuple) and len(x) == 2:
    host, port = x
    mode = "http"
elif isinstance(x, tuple) and len(x) == 3:
    host, port, mode = x

# After
match x:
    case host, port:
        mode = "http"
    case host, port, mode:
        pass
```

**AST Traversal:**
```python
# Before
if (isinstance(node, BinOp) and node.op == "+"
        and isinstance(node.right, BinOp) and node.right.op == "*"):
    a, b, c = node.left, node.right.left, node.right.right

# After
match node:
    case BinOp("+", a, BinOp("*", b, c)):
        # Handle a + b*c
```

### Pattern Matching and Object-Oriented Programming

"Like the Visitor pattern, pattern matching allows for a strict separation of concerns: specific actions or data processing is independent of the class hierarchy or manipulated objects."

**Advantages over the Visitor Pattern:**
- Works with predefined and built-in classes
- Distinguishes between sequences of different lengths
- Accounts for inheritance automatically
- Better suited for multi-dispatch scenarios than single-dispatch OO methods

### Patterns and Functional Style

"Functional programming generally prefers a declarative style with a focus on relationships in data. Side effects are avoided whenever possible. Pattern matching thus naturally fits and highly supports functional programming style."

---

## Rationale

### Overview and Terminology

**Pattern Nesting and Subpattern Dependencies:**
"The success of a pattern match depends directly on the success of subpattern is thus a cornerstone of the design." A parent pattern is checked before subpatterns; if the parent fails, subpatterns are never evaluated.

**Binding vs. Assignment:**
"Patterns bind names to values rather than performing an assignment. This reflects the fact that patterns aim to not have side effects." The term "bind" emphasizes this distinction from traditional variable assignment.

### The Match Statement

**Syntax and Structure:**
The match statement evaluates an expression (the subject), finds the first matching pattern, and executes the associated code block.

**Indentation Design:**
"Although flat indentation would save some horizontal space, the cost of increased complexity or unusual rules is too high."

**Expression vs. Statement:**
"This would fit poorly with Python's statement-oriented nature and lead to unusually long and complex expressions and the need to invent new syntactic constructs or break well established syntactic rules."

**Soft Keyword Decision:**
- "The new parser doesn't require us to do this."
- Making them hard keywords would break existing code where these names appear as identifiers
- Finding an alternative keyword would face similar compatibility issues

#### Match Semantics

**First-to-Match Rule:**
"The patterns of different case clauses might overlap in that more than one case clause would match a given subject. The first-to-match rule ensures that the selection of a case clause for a given subject is unambiguous."

**Dynamic Execution Model:**
"patterns are tried in a strictly sequential order so that each case clause constitutes an actual statement. At the same time, we allow the interpreter to cache any information about the subject or change the order in which subpatterns are tried."

**Variable Binding and Scoping:**
Variables bound in patterns "outlive the respective case or match statements." "This is in line with existing Python structures such as for loops and with statements."

#### Guards

"From a conceptual point of view, patterns describe structural constraints on the subject in a declarative style, ideally without any side-effects." Guards bridge this by allowing dynamic evaluation where pure patterns are insufficient.

Guards are attached only to case clauses, not individual patterns, maintaining clear separation between structural and dynamic logic.

---

### Patterns

"Patterns fulfill two purposes: they impose (structural) constraints on the subject and they specify which data values should be extracted from the subject and bound to variables."

"Although patterns might superficially look like expressions, it is important to keep in mind that there is a clear distinction. In fact, no pattern is or contains an expression."

#### AS Patterns

"AS patterns fill this gap in that they allow the user to specify a general pattern as well as capture the subject in a variable."

**Rationale for "as" over ":=":**
- `as` indicates 'processing' (consistent with `import foo as bar`, `except E as err`)
- Better left-to-right data flow
- Avoids confusion with the walrus operator and class pattern attribute syntax

#### OR Patterns

"The OR pattern allows you to combine 'structurally equivalent' alternatives into a new pattern, i.e. several patterns can share a common handler."

**Variable Binding Constraint:**
All subpatterns in an OR pattern must bind the same set of variables to avoid undefined names in different branches.

**AND and NOT Patterns Not Included:**

The proposal deliberately excludes AND (`&`) and NOT (`!`) patterns. "However, it is not clear how useful this would be. The semantics for matching dictionaries, objects and sequences already incorporates an implicit 'and': all attributes and elements mentioned must be present for the match to succeed."

"Evidence shows NOT patterns are rarely useful outside double negation for scope control, which doesn't apply to Python. Guards provide more elegant solutions."

#### Literal Patterns

"Generally, the subject is compared to a literal pattern by means of standard equality (`x == y` in Python syntax)."

**Special Rule for Singletons:**
Three singleton values (`None`, `False`, `True`) match by identity (`is`) rather than equality.

"However, we believe that many users would be surprised finding that `case True:` matched the subject `1.0`, resulting in some subtle bugs and convoluted workarounds."

**Numeric Equality:**
`case 1.0:` and `case 1:` are "fully interchangeable" because `1.0 == 1` in Python.

**Excluded Features:**
- F-strings are excluded because they're not literal values
- Range matching (e.g., `1...6`) is rejected due to ambiguity about inclusivity, range type, and character ranges

#### Capture Patterns

"Capture patterns take on the form of a name that accepts any value and binds it to a (local) variable (unless the name is declared as `nonlocal` or `global`)."

**Uniqueness Constraint:**
"A name used for a capture pattern must not coincide with another capture pattern in the same pattern." This mirrors function parameters, which must be unique.

**Rationale Against Explicit Markers:**
Proposals to mark capture patterns (e.g., `?x`, `$x`, `=x`) were rejected:
- Based on misconception that pattern matching extends switch statements
- Would undermine pattern matching's core purpose: binding extracted values
- Explicit markers introduce unnecessary syntactic clutter

#### Wildcard Pattern

"The wildcard pattern is a special case of a 'capture' pattern: it accepts any value, but does not bind it to a variable."

**Symbol Choice Rationale:**
Underscore was chosen despite alternatives:
- Already established in iterable unpacking
- Universal in every language with pattern matching: "C#, Elixir, Erlang, F#, Grace, Haskell, Mathematica, OCaml, Ruby, Rust, Scala, Swift, and Thorn"

**Else Block Rejection:**
`case _:` is not equivalent to an `else:` block syntactically because either could follow `case` without ambiguity, making indentation placement contentious.

#### Value Patterns

"Strictly speaking, value patterns are not really necessary, but could be implemented using guards, i.e. `case (status, body) if status == HttpStatus.OK:`. Nonetheless, the convenience of value patterns is unquestioned and obvious."

**Rule for Distinguishing from Capture Patterns:**
"Any dotted name (i.e., attribute access) is to be interpreted as a value pattern." This precludes local/global variables from acting as constants.

**Rejected Alternatives:**
- **Case sensitivity convention:** No precedent in core Python
- **Leading dot notation (`.CONSTANT`):** Insufficient visual marking
- **Global variable treatment:** Would create unintended side effects when module variables change

"The current proposal therefore leaves the discussion and possible introduction of such a 'constant' marker for a future PEP."

#### Sequence Patterns

**Sequence Type Requirement:**
"The sequence pattern does _not_ iterate through an iterable subject. All elements are accessed through subscripting and slicing, and the subject must be an instance of `collections.abc.Sequence`."

Rationale: "A sequence pattern cannot just iterate through any iterable object. The consumption of elements from the iteration would have to be undone if the overall pattern fails, which is not feasible."

**String and Bytes Exclusion:**
"String and bytes objects have a dual nature: they are both 'atomic' objects in their own right, as well as sequences (with a strongly recursive nature in that a string is a sequence of strings)."

"The typical behavior and use cases for strings and bytes are different enough from those of tuples and lists to warrant a clear distinction."

#### Mapping Patterns

**Structural Subtyping Rationale:**
"Dictionaries...have natural structural sub-typing behavior, i.e., passing a dictionary with extra keys somewhere will likely just work. Should it be necessary to impose an upper bound on the mapping and ensure that no additional keys are present, then the usual double-star-pattern `**rest` can be used."

#### Class Patterns

"Anecdotal evidence revealed that `isinstance()` is one of the most often used functions in Python in terms of static occurrences in programs."

**Rationale for `__match_args__`:**
"In a way, `__match_args__` is similar to the declaration of formal parameters, which allows calling functions with positional arguments rather than naming all the parameters."

**Mirroring Construction Syntax:**
"The syntax of class patterns is based on the idea that de-construction mirrors the syntax of construction. This is already the case in virtually any Python construct, be assignment targets, function definitions or iterable unpacking."

**Type Annotations Rejected:**
Proposals to combine patterns with type annotations were rejected due to:
- Syntax ambiguity (colons only work inside brackets/parentheses)
- Generic types don't work with `isinstance()` checks

---

## Backwards Compatibility

"Through its use of "soft keywords" and the new PEG parser ([PEP 617](../pep-0617/)), the proposal remains fully backwards compatible."

"3rd party tooling that uses a LL(1) parser to parse Python source code may be forced to switch parser technology to be able to support those same features."

---

## Security Implications

"We do not expect any security implications from this language feature."


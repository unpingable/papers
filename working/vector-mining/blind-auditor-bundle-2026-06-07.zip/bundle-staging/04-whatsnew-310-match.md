# Python 3.10 What's New — Structural Pattern Matching section

**Source URL:** https://docs.python.org/3/whatsnew/3.10.html#pep-634-structural-pattern-matching
**Fetched:** 2026-06-06 via WebFetch (mostly verbatim — see § 4 note)
**Altitude:** changelog / user-facing release residue

## Section content (verbatim from fetch)

Structural pattern matching has been added in the form of a *match statement* and *case statements* of patterns with associated actions. Patterns consist of sequences, mappings, primitive data types as well as class instances. Pattern matching enables programs to extract information from complex data types, branch on the structure of data, and apply specific actions based on different forms of data.

## Syntax and operations

The generic syntax of pattern matching is:

```python
match subject:
    case <pattern_1>:
        <action_1>
    case <pattern_2>:
        <action_2>
    case <pattern_3>:
        <action_3>
    case _:
        <action_wildcard>
```

A match statement takes an expression and compares its value to successive patterns given as one or more case blocks. Specifically, pattern matching operates by:

1. using data with type and shape (the `subject`)
2. evaluating the `subject` in the `match` statement
3. comparing the subject with each pattern in a `case` statement from top to bottom until a match is confirmed.
4. executing the action associated with the pattern of the confirmed match
5. If an exact match is not confirmed, the last case, a wildcard `_`, if provided, will be used as the matching case. If an exact match is not confirmed and a wildcard case does not exist, the entire match block is a no-op.

## Declarative approach

Readers may be aware of pattern matching through the simple example of matching a subject (data object) to a literal (pattern) with the **switch statement found in C, Java or JavaScript** (and many other languages). Often the switch statement is used for comparison of an object/expression with case statements containing literals.

More powerful examples of pattern matching can be found in languages such as Scala and Elixir. With structural pattern matching, the approach is "declarative" and explicitly states the conditions (the patterns) for data to match.

While an "imperative" series of instructions using nested "if" statements could be used to accomplish something similar to structural pattern matching, it is less clear than the "declarative" approach. Instead the "declarative" approach states the conditions to meet for a match and is more readable through its explicit patterns. While structural pattern matching can be used in its simplest form comparing a variable to a literal in a case statement, its true value for Python lies in its handling of the subject's type and shape.

## Simple pattern: match to a literal

```python
def http_error(status):
    match status:
        case 400:
            return "Bad request"
        case 404:
            return "Not found"
        case 418:
            return "I'm a teapot"
        case _:
            return "Something's wrong with the internet"
```

If the above function is passed a `status` of 418, "I'm a teapot" is returned. If the above function is passed a `status` of 500, the case statement with `_` will match as a wildcard, and "Something's wrong with the internet" is returned. Note the last block: the variable name, `_`, acts as a *wildcard* and insures the subject will always match. The use of `_` is optional.

You can combine several literals in a single pattern using `|` ("or"):

```python
case 401 | 403 | 404:
    return "Not allowed"
```

### Behavior without the wildcard

If we modify the above example by removing the last case block, the example becomes:

```python
def http_error(status):
    match status:
        case 400:
            return "Bad request"
        case 404:
            return "Not found"
        case 418:
            return "I'm a teapot"
```

Without the use of `_` in a case statement, a match may not exist. If no match exists, the behavior is a no-op. For example, if `status` of 500 is passed, a no-op occurs.

## Patterns with a literal and variable

```python
# point is an (x, y) tuple
match point:
    case (0, 0):
        print("Origin")
    case (0, y):
        print(f"Y={y}")
    case (x, 0):
        print(f"X={x}")
    case (x, y):
        print(f"X={x}, Y={y}")
    case _:
        raise ValueError("Not a point")
```

The first pattern has two literals, `(0, 0)`, and may be thought of as an extension of the literal pattern shown above. The next two patterns combine a literal and a variable, and the variable *binds* a value from the subject (`point`). The fourth pattern captures two values, which makes it conceptually similar to the unpacking assignment `(x, y) = point`.

## Patterns and classes

(class pattern example, full code preserved)

### Patterns with positional parameters

(positional pattern equivalences explained)

## Nested patterns

(nested example preserved)

## Complex patterns and the wildcard

To this point, the examples have used `_` alone in the last case statement. A wildcard can be used in more complex patterns, such as `('error', code, _)`.

## Guard

We can add an `if` clause to a pattern, known as a "guard". If the guard is false, `match` goes on to try the next case block. **Note that value capture happens before the guard is evaluated**:

```python
match point:
    case Point(x, y) if x == y:
        print(f"The point is located on the diagonal Y=X at {x}.")
    case Point(x, y):
        print(f"Point is not on the diagonal.")
```

## Other Key Features

- Like unpacking assignments, tuple and list patterns have exactly the same meaning and actually match arbitrary sequences. Technically, the subject must be a sequence. Therefore, an important exception is that patterns don't match iterators. Also, to prevent a common mistake, sequence patterns don't match strings.
- Sequence patterns support wildcards: `[x, y, *rest]` and `(x, y, *rest)` work similar to wildcards in unpacking assignments. The name after `*` may also be `_`, so `(x, y, *_)` matches a sequence of at least two items without binding the remaining items.
- Mapping patterns: `{"bandwidth": b, "latency": l}` captures the `"bandwidth"` and `"latency"` values from a dict. **Unlike sequence patterns, extra keys are ignored.** A wildcard `**rest` is also supported. (But `**_` would be redundant, so is not allowed.)
- Subpatterns may be captured using the `as` keyword.
- **Most literals are compared by equality. However, the singletons `True`, `False` and `None` are compared by identity.**
- Named constants may be used in patterns. **These named constants must be dotted names to prevent the constant from being interpreted as a capture variable.**

For the full specification see PEP 634. Motivation and rationale are in PEP 635, and a longer tutorial is in PEP 636.


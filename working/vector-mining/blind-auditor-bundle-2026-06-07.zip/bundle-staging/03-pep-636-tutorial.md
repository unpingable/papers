# PEP 636 – Structural Pattern Matching: Tutorial

**Source URL:** https://peps.python.org/pep-0636/
**Fetched:** 2026-06-06 via WebFetch (partially verbatim, with extensive code examples)
**Altitude:** user-facing / tutorial docs
**Status:** Final | **Type:** Informational | **Python Version:** 3.10

## Abstract

This PEP provides a tutorial for pattern matching introduced by PEP 634. It addresses concerns about explainability by offering learning material for developers.

## Core Pattern Types

### Capture Patterns
Stand-alone names that bind values from the subject.

### Literal Patterns
String literals, numbers, `True`, `False`, and `None`. These "are compared with the `==` operator except for the constants `True`, `False` and `None` which are compared with the `is` operator."

### Wildcard Pattern
The underscore `_` always matches but binds no variables. "Note that this will match any object, not just sequences. As such, it only makes sense to have it by itself as the last pattern (to prevent errors, Python will stop you from using it before)."

## Tutorial Examples

### Matching Sequences

```python
match command.split():
    case [action, obj]:
        ... # interpret action, obj
```

### Multiple Patterns

"The match statement will check patterns from top to bottom. If the pattern doesn't match the subject, the next pattern will be tried. However, once the _first_ matching pattern is found, the body of that case is executed, and all further cases are ignored."

### Matching Specific Values

```python
match command.split():
    case ["quit"]:
        print("Goodbye!")
        quit_game()
    case ["look"]:
        current_room.describe()
    case ["get", obj]:
        character.get(obj, current_room)
    case ["go", direction]:
        current_room = current_room.neighbor(direction)
```

"A pattern like `["get", obj]` will match only 2-element sequences that have a first element equal to `"get"`. It will also bind `obj = subject[1]`."

### Matching Multiple Values with Unpacking

"This will match any sequences having "drop" as its first elements. All remaining elements will be captured in a `list` object which will be bound to the `objects` variable. This syntax has similar restrictions as sequence unpacking: you can not have more than one starred name in a pattern."

### Or Patterns

"An important restriction when writing or patterns is that all alternatives should bind the same variables. So a pattern `[1, x] | [2, y]` is not allowed because it would make unclear which variable would be bound after a successful match."

### As Pattern (Capturing Matched Sub-patterns)

"The as-pattern matches whatever pattern is on its left-hand side, but also binds the value to a name."

### Guards (Adding Conditions)

"The guard is not part of the pattern, it's part of the case. It's only checked if the pattern matches, and after all the pattern variables have been bound."

### Object Matching

"A pattern like `Click(position=(x, y))` only matches if the type of the event is a subclass of the `Click` class... A pattern like `KeyPress()`, with no arguments will match any object which is an instance of the `KeyPress` class."

### Positional Attributes

"The `(x, y)` pattern will be automatically matched against the `position` attribute, because the first argument in the pattern corresponds to the first attribute in your dataclass definition."

### Matching Against Constants and Enums

"This will work with any dotted name (like `math.pi`). However an unqualified name (i.e. a bare name with no dots) will be always interpreted as a capture pattern, **so avoid that ambiguity by always using qualified constants in patterns**."

### Mapping Patterns

"The keys in your mapping pattern need to be literals, but the values can be any pattern... You can use `**rest` within a mapping pattern to capture additional keys in the subject... if you omit this, extra keys in the subject will be ignored while matching."

## Key Features Summary

- "Like unpacking assignments, tuple and list patterns have exactly the same meaning and actually match arbitrary sequences. An important exception is that they don't match iterators or strings."
- "Most literals are compared by equality, however the singletons `True`, `False` and `None` are compared by identity."
- Named constants "must be dotted names to prevent them from being interpreted as capture variable."


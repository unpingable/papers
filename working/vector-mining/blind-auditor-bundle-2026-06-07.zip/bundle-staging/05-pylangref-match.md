# Python Language Reference — The `match` statement

**Source URL:** https://docs.python.org/3/reference/compound_stmts.html#the-match-statement
**Fetched:** 2026-06-06 via WebFetch (verbatim — grammar BNF + normative text preserved closely)
**Altitude:** normative spec / language reference (post-PEP, post-implementation, post-doc-team-revision)

## 8.6. The `match` statement

Added in version 3.10.

Syntax:

```
match_stmt:   'match' subject_expr ":" NEWLINE INDENT case_block+ DEDENT
subject_expr: flexible_expression "," [flexible_expression_list [',']]
              | assignment_expression
case_block:   'case' patterns [guard] ":" suite
```

Note: This section uses single quotes to denote soft keywords.

Pattern matching takes a pattern as input (following `case`) and a subject value (following `match`). The pattern (which may contain subpatterns) is matched against the subject value. The outcomes are:

- A match success or failure (also termed a pattern success or failure).
- Possible binding of matched values to a name. The prerequisites for this are further discussed below.

The `match` and `case` keywords are soft keywords.

### 8.6.1. Overview

1. The subject expression `subject_expr` is evaluated and a resulting subject value obtained. If the subject expression contains a comma, a tuple is constructed using the standard rules.
2. Each pattern in a `case_block` is attempted to match with the subject value. The specific rules for success or failure are described below. The match attempt can also bind some or all of the standalone names within the pattern. The precise pattern binding rules vary per pattern type and are specified below. **Name bindings made during a successful pattern match outlive the executed block and can be used after the match statement**.

   Note: During failed pattern matches, **some subpatterns may succeed**. Do not rely on bindings being made for a failed match. Conversely, do not rely on variables remaining unchanged after a failed match. The exact behavior is dependent on implementation and may vary. This is an intentional decision made to allow different implementations to add optimizations.

3. If the pattern succeeds, the corresponding guard (if present) is evaluated. In this case all name bindings are guaranteed to have happened.
   - If the guard evaluates as true or is missing, the `block` inside `case_block` is executed.
   - Otherwise, the next `case_block` is attempted as described above.
   - If there are no further case blocks, the match statement is completed.

Note: Users should generally **never rely on a pattern being evaluated**. Depending on implementation, the interpreter may cache values or use other optimizations which skip repeated evaluations.

### 8.6.2. Guards

```
guard: "if" assignment_expression
```

- Check that the pattern in the `case` block succeeded. If the pattern failed, the `guard` is **not evaluated** and the next `case` block is checked.
- If the pattern succeeded, evaluate the `guard`.
- If the `guard` raises an exception during evaluation, the exception bubbles up.
- **Guards are allowed to have side effects as they are expressions.** Guard evaluation must proceed from the first to the last case block, one at a time, skipping case blocks whose pattern(s) don't all succeed. Guard evaluation must stop once a case block is selected.

### 8.6.3. Irrefutable Case Blocks

An irrefutable case block is a match-all case block. A match statement may have at most one irrefutable case block, and it must be last.

A case block is considered irrefutable if it has no guard and its pattern is irrefutable. Only the following patterns are irrefutable:

- AS Patterns whose left-hand side is irrefutable
- OR Patterns containing at least one irrefutable pattern
- Capture Patterns
- Wildcard Patterns
- parenthesized irrefutable patterns

### 8.6.4. Patterns

```
patterns:       open_sequence_pattern | pattern
pattern:        as_pattern | or_pattern
closed_pattern: | literal_pattern
                | capture_pattern
                | wildcard_pattern
                | value_pattern
                | group_pattern
                | sequence_pattern
                | mapping_pattern
                | class_pattern
```

#### 8.6.4.1. OR Patterns

```
or_pattern: "|".closed_pattern+
```

Only the final subpattern may be irrefutable, and each subpattern must bind the same set of names to avoid ambiguity.

#### 8.6.4.2. AS Patterns

```
as_pattern: or_pattern "as" capture_pattern
```

`capture_pattern` cannot be a `_`.

#### 8.6.4.3. Literal Patterns

```
literal_pattern: signed_number
                 | signed_number "+" NUMBER
                 | signed_number "-" NUMBER
                 | strings
                 | "None"
                 | "True"
                 | "False"
signed_number:   ["-"] NUMBER
```

f-strings and t-strings are **not supported**.

In simple terms, `LITERAL` will succeed only if `<subject> == LITERAL`. For the singletons `None`, `True` and `False`, the `is` operator is used.

#### 8.6.4.4. Capture Patterns

```
capture_pattern: !'_' NAME
```

A single underscore `_` is not a capture pattern (this is what `!'_'` expresses).

In a given pattern, a given name can only be bound once. E.g. `case x, x: ...` is invalid while `case [x] | x: ...` is allowed.

Capture patterns always succeed. The binding follows scoping rules established by the assignment expression operator in PEP 572; the name becomes a local variable in the closest containing function scope unless there's an applicable `global` or `nonlocal` statement.

#### 8.6.4.5. Wildcard Patterns

```
wildcard_pattern: '_'
```

`_` is a soft keyword **within any pattern, but only within patterns**. It is an identifier, as usual, even within `match` subject expressions, `guard`s, and `case` blocks.

#### 8.6.4.6. Value Patterns

```
value_pattern: attr
attr:          name_or_attr "." NAME
name_or_attr:  attr | NAME
```

The dotted name in the pattern is looked up using standard Python name resolution rules. The pattern succeeds if the value found compares equal to the subject value (using the `==` equality operator).

Note: If the same value occurs multiple times in the same match statement, **the interpreter may cache the first value found and reuse it** rather than repeat the same lookup. This cache is strictly tied to a given execution of a given match statement.

#### 8.6.4.7. Group Patterns

```
group_pattern: "(" pattern ")"
```

In simple terms `(P)` has the same effect as `P`.

#### 8.6.4.8. Sequence Patterns

```
sequence_pattern:       "[" [maybe_sequence_pattern] "]"
                        | "(" [open_sequence_pattern] ")"
open_sequence_pattern:  maybe_star_pattern "," [maybe_sequence_pattern]
maybe_sequence_pattern: ",".maybe_star_pattern+ ","?
maybe_star_pattern:     star_pattern | pattern
star_pattern:           "*" (capture_pattern | wildcard_pattern)
```

There is no difference if parentheses or square brackets are used for sequence patterns.

Note: A single pattern enclosed in parentheses without a trailing comma (e.g. `(3 | 4)`) is a group pattern. While a single pattern enclosed in square brackets (e.g. `[3 | 4]`) is still a sequence pattern.

Logical flow:
1. If the subject value is not a sequence, the sequence pattern fails.
2. **If the subject value is an instance of `str`, `bytes` or `bytearray` the sequence pattern fails.**
3. (fixed vs variable-length matching, omitted here for brevity)

Note: The length of the subject sequence is obtained via `len()` (i.e. via the `__len__()` protocol). This length **may be cached** by the interpreter.

#### 8.6.4.9. Mapping Patterns

```
mapping_pattern:     "{" [items_pattern] "}"
items_pattern:       ",".key_value_pattern+ ","?
key_value_pattern:   (literal_pattern | value_pattern) ":" pattern
                     | double_star_pattern
double_star_pattern: "**" capture_pattern
```

Duplicate keys in mapping patterns are disallowed. Duplicate literal keys will raise a `SyntaxError`. Two keys that otherwise have the same value will raise a `ValueError` at runtime.

Logical flow:
1. If the subject value is not a mapping, the mapping pattern fails.
2. If every key given in the mapping pattern is present in the subject mapping, and the pattern for each key matches the corresponding item of the subject mapping, the mapping pattern succeeds.

Note: Key-value pairs are matched using the two-argument form of the mapping subject's `get()` method. Matched key-value pairs must already be present in the mapping, and not created on-the-fly via `__missing__()` or `__getitem__()`.

#### 8.6.4.10. Class Patterns

```
class_pattern:       name_or_attr "(" [pattern_arguments] ","? ")"
pattern_arguments:   [positional_patterns] ["," keyword_patterns]
                     | keyword_patterns
positional_patterns: ",".pattern+
keyword_patterns:    ",".keyword_pattern+
keyword_pattern:     NAME "=" pattern
```

Logical flow:
1. If `name_or_attr` is not an instance of the builtin `type`, raise `TypeError`.
2. If the subject value is not an instance of `name_or_attr` (tested via `isinstance()`), the class pattern fails.
3. (positional + keyword arg processing — see source)

For the following built-in types the handling of positional subpatterns is different:

- `bool`, `bytearray`, `bytes`, `dict`, `float`, `frozenset`, `int`, `list`, `set`, `str`, `tuple`

These classes accept a single positional argument, and the pattern there is matched against the whole object rather than an attribute. For example `int(0|1)` matches the value `0`, but not the value `0.0`.


author:	bedevere-bot
association:	none
edited:	false
status:	none
--
:robot: New build scheduled with the buildbot fleet by @brandtbucher for commit 5589f77c856cca6e126c1e1fa6ef95f4d097f6e9 :robot:

If you want to schedule another build, you need to add the ":hammer: test-with-buildbots" label again.

--
author:	brandtbucher
association:	member
edited:	true
status:	none
--
So I see three categories of buildbot failures:

- Memory leaks in `test_io` (all Refleak jobs).
- Undefined references to `_Py_Mangle` and `PyAST_CompileObject` during LTO (all Fedora Stable LTO jobs).
- Segfaults in `testlib2to3` (PPC64LE RHEL7 LTO, s390x Fedora LTO PR, s390x RHEL8 LTO + PGO).

I’ve verified that all of these same failures occur on the 3.x buildbots, so I think they can be safely ignored here.
--
author:	pablogsal
association:	member
edited:	true
status:	none
--
> So I see three categories of buildbot failures:

Thanks @brandtbucher! 

I am going to try to fix the segfaults first, as we have a release soon of 3.10 alpha 2 and I don't want those segfaults to be there.
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
Also, if any core devs are eavesdropping and haven't voted for Batuhan's promotion yet, please [do so](https://discuss.python.org/t/vote-to-promote-batuhan-taskaya)! He's absolutely earned it.
--
author:	markshannon
association:	member
edited:	false
status:	none
--

```python
def f(t):
    a, b, p, q, x, y = [None]*6
    match t:
        case []:
            pass
        case [x]:
            y = 2
        case [a, b] if a == b:
            pass
        case [p, q]:
            pass
    print(a,b,p,q,x,y)

f((1,2))
```
This prints `1 2 1 2 None None`, instead of `None None 1 2 None None`.
Since `[a, b] if a == b` doesn't match, why are values assigned to `a` and `b`?
`[x]` doesn't match, and `x` is not assigned to.

--
author:	brandtbucher
association:	member
edited:	true
status:	none
--
Hi Mark.

PEP 634 says (in regard to name bindings in patterns):

> These may happen earlier or later depending on the implementation strategy, the only constraint being that capture variables must be set before guards that use them explicitly are evaluated.

In general, there are two points to keep in mind for cases like yours:

- Cases consist of patterns and guards. These are separate conditions. While the language of the PEP allows checking guard conditions while matching the pattern (which this implementation doesn't do), the main constraint is that any names used by the guard have already been bound, as you experienced.

- The implementation, while still quite naïve at this point, will quit matching as soon as a pattern is proven to be a non-match. In your first and second cases, we jump to the next case as soon as we observe a sequence of incompatible length.
--
author:	markshannon
association:	member
edited:	false
status:	none
--
So the bug is in the PEP, not the implementation?
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
> So the bug is in the PEP, not the implementation?

It's not a bug, it's part of the spec. We even mention it twice:

> During failed pattern matches, some subpatterns may succeed. For example, while matching the pattern (0, x, 1) with the value [0, 1, 2], the subpattern x may succeed if the list elements are matched from left to right. The implementation may choose to either make persistent bindings for those partial matches or not. User code including a match statement should not rely on the bindings being made for a failed match, but also shouldn't assume that variables are unchanged by a failed match. This part of the behavior is left intentionally unspecified so different implementations can add optimizations, and to prevent introducing semantic restrictions that could limit the extensibility of this feature.
--
author:	markshannon
association:	member
edited:	false
status:	none
--
Why inflict that on users?
Why not say "all variables in the matching pattern will be assigned, and none in patterns that don't match."
It sounds like you are deliberately trying to trip people up.

And please don't use "optimization" as an excuse, that's just lazy.
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
This isn't the place to discuss PEP 634.

Perhaps take it up in [gvanrossum/patma](https://github.com/gvanrossum/patma) (relevant discussion in https://github.com/gvanrossum/patma/issues/110). It's been pretty quiet lately since the spec has matured.
--
author:	asottile
association:	contributor
edited:	false
status:	none
--
one thing I noticed (not sure if it's intentional or an oversight): `Ellipsis` / `...` are not matched as literals.  should those be included (similar to `True `/ `False` / `None`)?
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
@asottile I believe we briefly considered this but decided against it. If I remember correctly, it was to avoid confusion (since it looks a bit like a wildcard-y construct):

```
match items:
    case [first, ..., last]: pass
```

If you're glancing over that code, you could be forgiven for thinking it does something like this:

```
match items:
    case [first, *_, last]: pass
```

There may have also been some worry about it appearing to be some sort of range match:

```
match character:
    case "A", ..., "Z": pass
    case "a", ..., "z": pass
```

(Note that `...` is currently disallowed in the pattern grammar, so we could always allow it later if a compelling use-case were raised.)
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
(Also `Ellipsis` is just a builtin name, not a literal like `True`/`False`/`None`.)
--
author:	markshannon
association:	member
edited:	false
status:	changes requested
--
There is a lot work being done in the interpreter and helper functions that should be done in the compiler.

The `MATCH_KEYS` bytecode should be split up.
`GET_INDEX` and `GET_INDEX_SLICE` can be eliminated.

The `MATCH_CLASS` and `MATCH_MAPPING` bytecodes also need breaking up, but that could wait. 
--
author:	bedevere-bot
association:	none
edited:	false
status:	none
--
<!-- changes-requested -->
When you're done making the requested changes, leave the comment: `I have made the requested changes; please review again`.
<!-- /changes-requested -->



--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
Thanks! I'll try to address most of these today.
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
Okay, I've broken off `COPY_DICT_WITHOUT_KEYS` from `MATCH_KEYS`. I've also gotten rid of all of the `GET_INDEX*` instructions.

`compiler_pattern_sequence` is a mess right now, but it works. I'm going to refactor and clean it up tomorrow, so I don't recommend burning a lot of time on it.
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
Update: I saw an opportunity to greatly improve the emitted bytecode, so I did a slight refactoring of some of the compiler routines today.

The main change is that we no longer preserve the subject of the match as a convention in `compiler_pattern_*` routines... now they just consume it from the stack, replacing it with `True` or `False`. This avoids lots of wasteful `DUP_TOP`s, and simplifies the control flow to a level that the peephole/CFG passes can infer and optimize much more effectively. You can see commit 3f8fdaf for full diff.

Here's a before-and-after for a simple snippet:

```py
match x:
    case a, b:
        pass
```

```py
  1           0 LOAD_NAME                0 (x)

  2           2 MATCH_SEQUENCE
              4 POP_JUMP_IF_FALSE       58
              6 GET_LEN
              8 LOAD_CONST               0 (2)
             10 COMPARE_OP               2 (==)
             12 POP_JUMP_IF_FALSE       58
             14 DUP_TOP
             16 UNPACK_SEQUENCE          2
             18 DUP_TOP
             20 STORE_NAME               1 (a)
             22 LOAD_CONST               1 (True)
             24 ROT_TWO
             26 POP_TOP
             28 POP_JUMP_IF_FALSE       46
             30 DUP_TOP
             32 STORE_NAME               2 (b)
             34 LOAD_CONST               1 (True)
             36 ROT_TWO
             38 POP_TOP
             40 POP_JUMP_IF_FALSE       48
             42 LOAD_CONST               1 (True)
             44 JUMP_FORWARD             4 (to 50)
        >>   46 POP_TOP
        >>   48 LOAD_CONST               2 (False)
        >>   50 POP_JUMP_IF_FALSE       58
             52 POP_TOP
             54 LOAD_CONST               3 (None)
             56 RETURN_VALUE
        >>   58 POP_TOP
             60 LOAD_CONST               3 (None)
             62 RETURN_VALUE
```

```py
  1           0 LOAD_NAME                0 (x)

  2           2 MATCH_SEQUENCE
              4 POP_JUMP_IF_FALSE       24
              6 GET_LEN
              8 LOAD_CONST               0 (2)
             10 COMPARE_OP               2 (==)
             12 POP_JUMP_IF_FALSE       24
             14 UNPACK_SEQUENCE          2
             16 STORE_NAME               1 (a)
             18 STORE_NAME               2 (b)
             20 LOAD_CONST               1 (True)
             22 JUMP_FORWARD             4 (to 28)
        >>   24 POP_TOP
             26 LOAD_CONST               2 (False)
        >>   28 POP_JUMP_IF_FALSE       34
             30 LOAD_CONST               3 (None)
             32 RETURN_VALUE
        >>   34 LOAD_CONST               3 (None)
             36 RETURN_VALUE
```
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
I'd encourage anybody who hasn't already begun reviewing this PR to start soon! We have only two more alphas, and the next is in just 10 days.

@pablogsal, when's the latest you'd be comfortable merging this before the release? I assume by the end of next week?
--
author:	pablogsal
association:	member
edited:	false
status:	none
--
> when's the latest you'd be comfortable merging this before the release?

Do you mean before the alpha release? Given that a lot of people would be waiting for the next alpha to play with this, we can merge it even on the same day if is required. We can stay in contact via email if it comes to that. Or are you referring to beta freeze?

In any case, I would like to make a review pass, but these weeks I have been fighting lots of stuff and it has been impossible to find some time for it. Hopefully, I can get to it at the weekend :)
--
author:	brandtbucher
association:	member
edited:	true
status:	none
--
Gotcha. Yeah, I was referring to the next alpha, scheduled for 3/1. I thought maybe you might need a day or two between tagging and releasing or something.
--
author:	pablogsal
association:	member
edited:	true
status:	none
--
> I thought maybe you might need a day or two between tagging and releasing or something.

No, although is a multi-hour process, I normally do it on the same day as the release, at least for the alphas (assuming everything goes smoothly).
--
author:	willingc
association:	contributor
edited:	false
status:	commented
--
@brandtbucher I did an initial pass and it looks good for alpha. I will look at it more closely this weekend.
--
author:	asottile
association:	contributor
edited:	false
status:	none
--
found a bit of an odd case while trying this out -- not sure if it's intentional:

```python
x = 1

match x:
    case 1 as y if 0:
        print('unreachable')
print(f'{y=}')  # expect NameError
```

instead of NameError I get `y=1`
--
author:	pablogsal
association:	member
edited:	false
status:	none
--
> found a bit of an odd case while trying this out -- not sure if it's intentional:
> 
> ```python
> x = 1
> 
> match x:
>     case 1 as y if 0:
>         print('unreachable')
> print(f'{y=}')  # expect NameError
> ```
> 
> instead of NameError I get `y=1`

IIRC I think that is covered in https://www.python.org/dev/peps/pep-0634/#side-effects-and-undefined-behavior, although the peephole could detect the branch and optimize it away.
--
author:	brandtbucher
association:	member
edited:	true
status:	none
--
Yeah, we're required to bind any names used by the guard before evaluating it (obviously). The current naive implementation accomplishes this by binding all names before hitting *any* guard. Strange example, but legal by the PEP.

I'm actually not sure the peephole/CFG could catch this (it can optimize out the body of the case, though, and it actually does here). Might be something for the AST optimizer.
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
I believe I have addressed all of the comments so far. If anyone still has additional feedback (or needs the weekend to review), please let me know. Otherwise, I'll plan on merging this Friday.

@pablogsal, should we hit it with the buildbots again?
--
author:	bedevere-bot
association:	none
edited:	false
status:	none
--
:robot: New build scheduled with the buildbot fleet by @pablogsal for commit 61616fc3b4edb069bb4494837b6f76acb33cd4a6 :robot:

If you want to schedule another build, you need to add the ":hammer: test-with-buildbots" label again.

--
author:	brandtbucher
association:	member
edited:	true
status:	none
--
The three failed jobs look unrelated to these changes; I see the same failures (with the same logs) on #24643.
--
author:	brandtbucher
association:	member
edited:	false
status:	none
--
Okay, I'm going to merge this. 🍾

Big thanks to everyone who took time to help out here! 
--

# PEP 634: Structural Pattern Matching — Specification

**Source URL:** https://peps.python.org/pep-0634/
**Fetched:** 2026-06-06 via WebFetch (model-summarized; key normative claims quoted; not full verbatim)
**Altitude:** spec / normative proposal

## Purpose
PEP 634 provides the technical specification for Python's `match` statement, introduced in Python 3.10. It replaces PEP 622 and focuses purely on the specification while delegating motivation to PEP 635 and tutorials to PEP 636.

## Core Components

**Match Statement Structure:**
The match statement evaluates a subject expression and selects the first case block whose pattern succeeds and whose guard (if present) is truthy.

**Pattern Types Defined:**
- **Literal Patterns**: Match specific values (numbers, strings, None, True, False)
- **Capture Patterns**: Bind the subject to a name
- **Wildcard Pattern**: Matches anything without binding (`_`)
- **Value Patterns**: Match dotted names against subject values
- **Group Patterns**: Parenthesized patterns for emphasis
- **Sequence Patterns**: Match sequences like lists/tuples with fixed or variable lengths
- **Mapping Patterns**: Match dictionaries with specific keys
- **Class Patterns**: Match class instances and extract attributes
- **OR Patterns**: Match alternatives separated by `|`
- **AS Patterns**: Bind matched results to names

## Key Normative Claims

- "match" and "case" are soft keywords, not reserved words, allowing their use as variable names in other contexts.
- Name bindings from successful pattern matches outlive the executed block.
- Guards evaluate in order and stop once a case block is selected.
- An irrefutable pattern (guaranteed to succeed) can only appear as the final case block.
- Sequence patterns exclude strings, bytes, and bytearray despite their sequence nature.
- Standard library classes like namedtuples and dataclasses receive auto-generated `__match_args__` attributes to support positional pattern matching.


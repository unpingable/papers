# Blind-Auditor Bundle — Cross-Altitude Novelty Audit

## What this is

A self-contained bundle for running a Cross-Altitude Novelty Audit on the Python PEP 634 family of documents. The audit task: classify five claims against a frozen corpus of eight documents using a fixed verdict palette.

## What's in this bundle

- `blind-auditor-bundle-2026-06-07.md` — **the main bundle.** Contains audit method, verdict palette, frozen corpus manifest, five claims, inline source excerpts (with bracketed IDs), required receipt format, and audit instructions. **Self-contained: no URL or file access required to perform the audit.**
- `sources/` — eight frozen source files (Markdown), one per document in the corpus manifest. Available for redundancy if you want surrounding context beyond the excerpts inlined in the main bundle. URLs in the manifest are for verification only.
- `README.md` — this file.

## How to perform the audit

1. Read `blind-auditor-bundle-2026-06-07.md` top to bottom.
2. For each of the five claims, scan the inline excerpts to identify supporting and refuting material.
3. Assign a verdict using ONLY the labels in the verdict palette. Multi-class verdicts are allowed.
4. Cite excerpts by their bracketed IDs.
5. Return a single markdown receipt in the format specified in the bundle.

## What this bundle does NOT contain

- Prior audit results.
- Examples of expected verdicts.
- Hints about which verdicts are common or rare for this audit method.
- The expected verdict distribution.
- Method history or doctrine about which the audit is being run.

If you are unsure about a verdict, your honest uncertainty marker is the right output. Do not guess in either direction.

## Source provenance

Sources were fetched 2026-06-06 via WebFetch (for documentation pages) and `gh` CLI (for GitHub issues / PRs). Direct URLs are provided in the manifest and in each excerpt header. Sources are frozen as of the fetch date; do not pull additional material from those URLs without marking it as out-of-bundle.
